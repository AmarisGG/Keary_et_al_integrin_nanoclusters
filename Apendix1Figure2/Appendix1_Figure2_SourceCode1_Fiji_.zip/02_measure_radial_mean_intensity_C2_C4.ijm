// ============================================================
// Appendix 1—figure 2: Fiji/ImageJ radial-intensity measurement
//
// Purpose:
//   Measure raw mean fluorescence intensity in each radial BIN ROI
//   for two STED channels (default C2 and C4).
//
// Requirements:
//   - Run 01_generate_radial_bins_60nm_to1000nm.ijm first
//   - Keep the ROI Manager and Results table open
//   - Channel windows must begin with "C2-" and "C4-" unless edited
//
// Main MATLAB input columns:
//   C2_meanRaw, C4_meanRaw
//
// No smoothing, background subtraction, normalization, averaging,
// edge-enrichment calculation, or statistics are performed here.
// ============================================================

stedChA = 2;
stedChB = 4;

function findChannelTitle(ch) {
    titles = getList("image.titles");

    for (i = 0; i < titles.length; i++) {
        if (startsWith(titles[i], "C" + ch + "-"))
            return titles[i];
    }

    return "";
}

function statsWithROI(winTitle, roiIndex) {
    selectWindow(winTitle);
    roiManager("Select", roiIndex);
    getStatistics(area, mean, min, max, std);
    return newArray(area, mean, min, max, std);
}

function rawWithROI(winTitle, roiIndex) {
    selectWindow(winTitle);
    roiManager("Select", roiIndex);

    setOption("Limit to Threshold", false);
    resetThreshold();

    getRawStatistics(nPix, meanRaw, minR, maxR, stdR);
    sumIntensity = meanRaw * nPix;

    return newArray(nPix, meanRaw, sumIntensity);
}

cA = findChannelTitle(stedChA);
cB = findChannelTitle(stedChB);

if (cA == "")
    exit("Cannot find an open image window beginning with C" + stedChA + "-.");

if (cB == "")
    exit("Cannot find an open image window beginning with C" + stedChB + "-.");

nTotal = roiManager("Count");

if (nTotal < 2)
    exit("Need one FA ROI plus radial BIN ROIs. Run Macro 1 first.");

if (nResults == 0)
    exit("Results table is empty. Run Macro 1 first.");

// ROI 0 = original FA contour; BIN ROIs start at ROI 1.
for (i = 1; i < nTotal; i++) {
    binId = i;
    row = binId - 1;

    if (row >= nResults)
        continue;

    sA = statsWithROI(cA, i);
    rA = rawWithROI(cA, i);

    sB = statsWithROI(cB, i);
    rB = rawWithROI(cB, i);

    setResult("BIN_id_check", row, binId);

    setResult("C" + stedChA + "_area",         row, sA[0]);
    setResult("C" + stedChA + "_min",          row, sA[2]);
    setResult("C" + stedChA + "_max",          row, sA[3]);
    setResult("C" + stedChA + "_nPix",         row, rA[0]);
    setResult("C" + stedChA + "_meanRaw",      row, rA[1]);
    setResult("C" + stedChA + "_sumIntensity", row, rA[2]);

    setResult("C" + stedChB + "_area",         row, sB[0]);
    setResult("C" + stedChB + "_min",          row, sB[2]);
    setResult("C" + stedChB + "_max",          row, sB[3]);
    setResult("C" + stedChB + "_nPix",         row, rB[0]);
    setResult("C" + stedChB + "_meanRaw",      row, rB[1]);
    setResult("C" + stedChB + "_sumIntensity", row, rB[2]);
}

updateResults();

print("Done. Added radial intensity measurements for C" + ...
      stedChA + " and C" + stedChB + ".");
print("Save the Results table as *_Results.csv for MATLAB processing.");
