// ============================================================
// Appendix 1—figure 2: Fiji/ImageJ radial-bin generation
//
// Purpose:
//   Generate consecutive 60-nm radial ROIs extending inward from a
//   manually defined focal-adhesion (FA) boundary.
//
// Important for reproducing the original MATLAB workflow:
//   Radial bins are generated to 1000 nm. MATLAB uses this range for
//   minimum subtraction and 0–1 normalization, then restricts the final
//   plotted/quantified analysis to <=600 nm.
//
// Input:
//   - Spatially calibrated image
//   - ROI Manager containing ONE closed FA ROI as the first ROI
//
// Output in Results:
//   BIN_id, bin_nm, bin_start_nm, bin_end_nm, bin_center_nm
// ============================================================

bin_nm = 60;
max_nm = 1000;

function nmToPx(nm) {
    getPixelSize(unit, pw, ph, pd);

    if (unit == "pixel" || unit == "pixels")
        exit("Image is not spatially calibrated. Set the pixel size first.");

    if (unit == "nm")
        return nm / pw;

    // Assume micrometre-scale calibration for other physical units
    // used in this workflow.
    return nm / (pw * 1000.0);
}

nR = roiManager("Count");
if (nR == 0)
    exit("ROI Manager is empty. Add ONE closed FA ROI first.");

faIdx = 0;

bin_px = nmToPx(bin_nm);
if (bin_px < 1) bin_px = 1;

max_px = nmToPx(max_nm);
if (max_px < 1) max_px = 1;

print("Radial bin size = " + bin_nm + " nm");
print("Maximum generated distance = " + max_nm + " nm");

roiManager("Select", faIdx);
run("Create Mask");
selectWindow("Mask");
run("Distance Map");

getStatistics(area, mean, min, maxDist, std);
if (maxDist > max_px) maxDist = max_px;

nBins = floor((maxDist - 1) / bin_px) + 1;
if (nBins < 1) {
    close();
    exit("No radial bins could be generated for this FA.");
}

// Remove old BIN ROIs but keep the original FA ROI.
nTotal0 = roiManager("Count");
if (nTotal0 > 1) {
    for (k = nTotal0 - 1; k >= 1; k--) {
        roiManager("Select", k);
        roiManager("Delete");
    }
}

run("Clear Results");

binCount = 0;

for (b = 0; b < nBins; b++) {
    d0 = 1 + b * bin_px;
    d1 = d0 + bin_px;

    if (d0 > maxDist) break;
    if (d1 > maxDist) d1 = maxDist;

    setThreshold(d0, d1);
    run("Create Selection");

    if (selectionType() == -1)
        continue;

    roiManager("Add");
    idxNew = roiManager("Count") - 1;

    binCount++;
    roiManager("Select", idxNew);
    roiManager("Rename", "BIN_" + binCount);

    start_nm  = (binCount - 1) * bin_nm;
    end_nm    = binCount * bin_nm;
    center_nm = start_nm + bin_nm / 2;

    row = nResults;
    setResult("BIN_id",        row, binCount);
    setResult("bin_nm",        row, bin_nm);
    setResult("bin_start_nm",  row, start_nm);
    setResult("bin_end_nm",    row, end_nm);
    setResult("bin_center_nm", row, center_nm);
    updateResults();
}

close();
print("Done. Created " + binCount + " radial BIN ROIs.");
