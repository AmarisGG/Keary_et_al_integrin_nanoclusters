Appendix 1—figure 2 — Fiji/ImageJ source code
================================================

FILES
-----
1. 01_generate_radial_bins_60nm_to1000nm.ijm
   Generates consecutive 60-nm radial BIN ROIs inward from a manually
   defined focal-adhesion boundary.

2. 02_measure_radial_mean_intensity_C2_C4.ijm
   Measures raw mean fluorescence intensity in each radial BIN ROI for
   STED channels C2 and C4.

RUN ORDER
---------
1. Open the spatially calibrated dual-color STED channel images.
2. Draw one closed FA contour and add it as the FIRST ROI in ROI Manager.
3. Run 01_generate_radial_bins_60nm_to1000nm.ijm.
4. Without clearing ROI Manager or Results, run
   02_measure_radial_mean_intensity_C2_C4.ijm.
5. Save the Results table as a CSV file, preferably *_Results.csv.

RADIAL RANGE
------------
The cleaned VOR macro generates 60-nm bins up to 1000 nm because the
original MATLAB workflow used the first 1000 nm of each individual FA
profile for minimum subtraction and 0–1 normalization.

The final plotted and quantified radial region is then restricted in
MATLAB to <=600 nm.

Nominal bin centers are:
30, 90, 150, 210, ... , 990 nm.

MAIN OUTPUT
-----------
Geometry:
- BIN_id
- bin_nm
- bin_start_nm
- bin_end_nm
- bin_center_nm

Raw fluorescence:
- C2_meanRaw
- C4_meanRaw

Additional QC columns:
- area
- min
- max
- nPix
- sumIntensity

The Fiji macros do not perform normalization, averaging, SEM calculation,
edge-enrichment analysis, or statistical testing. Those steps are
performed in MATLAB.
