Appendix 1–figure 2 — MATLAB source code
===============================================

This folder contains the MATLAB scripts used for the dual-color STED
radial-profile and edge-enrichment analyses shown in Appendix 1–figure 2C–D.


FILES
-----

Appendix1_Figure2_SourceCode1.m

Processes radial fluorescence-intensity profiles exported from Fiji/ImageJ
for each experimental condition.

For each focal adhesion (FA) and fluorescence channel, the script:

- reads radial mean fluorescence intensities up to 1000 nm from the FA edge;
- subtracts the minimum intensity of the individual radial profile;
- normalizes each radial profile to its maximum value (0–1);
- interpolates profiles onto a common radial-distance grid;
- calculates mean normalized intensity and SEM across FAs;
- reports radial profiles up to 600 nm;
- calculates FA-level edge enrichment as:

  mean normalized intensity at 60–180 nm /
  mean normalized intensity at 180–600 nm.

The script generates one processed workbook per experimental condition.


Appendix1_Figure2_SourceCode2.m

Reads the processed source-data workbook and generates the final plots
shown in Appendix 1–figure 2C–D.

The script generates:

- panel C:
  normalized radial fluorescence-intensity profiles
  (mean ± SEM);

- panel D:
  edge-enrichment boxplots displaying individual FA values.

The script performs two-sided Welch's t-tests for edge-enrichment
comparisons and exports statistical summaries.


INPUT
-----

Fiji/ImageJ radial-profile output files should contain:

- bin_center_nm
- C2_meanRaw

Additional fluorescence channels can be processed during the
radial-profile processing step if required.

The final plotting script requires a processed source-data Excel workbook
containing:

Radial profile data:
- bin_center_nm
- C2_meanNorm
- C2_SEM

FA-level edge-enrichment data:
- FA_file
- Accum_C2
- Enrich_C2


SOFTWARE
--------

MATLAB.

The scripts use standard MATLAB functions together with boxplot and ttest2.


OUTPUT
------

The final plotting script exports:

- PNG and vector SVG versions of Appendix 1–figure 2C;
- PNG and vector SVG versions of Appendix 1–figure 2D;
- an Excel workbook containing edge-enrichment summary statistics and
  Welch t-test results.


Channel numbers refer to image-channel identifiers; biological target
identity depends on the corresponding experiment.