%% =========================================================================
% Generate_STED_final_figure_02.m
%
% FINAL FIGURE GENERATION FROM SINGLE SOURCE DATA EXCEL
%
% Generates:
%   Appendix 1 - Figure 2C
%       Radial STED intensity profiles (mean +/- SEM)
%
%   Appendix 1 - Figure 2D
%       Edge enrichment boxplot + individual FA values
%
% Statistics:
%   Two-sided Welch t-tests (Part 2)
%
% =========================================================================


clear;
clc;
close all;


set(groot,'defaultAxesToolbarVisible','off');


%% =========================================================================
% USER SETTINGS
% =========================================================================

% Single source-data Excel file

sourceFile = '\\nas01\SMB02\Amaris\4- Proyectos Theory\Proyecto Sarah\Kearyetal_Paper_elife2025\Appendix 1-figure 2-source data 1\Appendix1_Figure2_SourceData.xlsx';



% Sheet order corresponds to figure order

sheetNames = {
    'Pax'
    'a5Tot'
    'actb1'
    'Ten3'
};


groupNames = {
    'Pax'
    'a5\beta1'
    'active \beta1'
    'Ten3'
};


channelToCompare = 2;

xMaxNm = 600;



%% =========================================================================
% COLORS
% =========================================================================

% Fixed publication order

fixedCols = [

    0.95 0.55 0.10   % Pax
    0.60 0.90 0.20   % alpha5 total
    0.05 0.45 0.20   % active beta1
    0.75 0.60 0.85   % Tensin3

];



%% =========================================================================
% OUTPUT
% =========================================================================

outputDir = 'FinalFigures';

if ~exist(outputDir,'dir')
    mkdir(outputDir);
end


timestamp = datestr(now,'yyyymmdd_HHMMSS');



%% =========================================================================
% READ RADIAL PROFILES FROM SINGLE EXCEL
%
% Each sheet:
%
% A:C
% bin_center_nm
% C2_meanNorm
% C2_SEM
%
% =========================================================================


nGroups = numel(sheetNames);


Xcell  = cell(nGroups,1);
MUcell = cell(nGroups,1);
SEcell = cell(nGroups,1);



for k = 1:nGroups


    fprintf('Reading radial data: %s\n',sheetNames{k});


    % Read columns A:C

    T = readtable( ...
        sourceFile,...
        'Sheet',sheetNames{k},...
        'Range','A:C');


    % Use column position for robustness

    x   = T{:,1};

    mu  = T{:,2};

    sem = T{:,3};



    keep = ...
        isfinite(x) & ...
        isfinite(mu) & ...
        isfinite(sem);



    x   = x(keep);

    mu  = mu(keep);

    sem = sem(keep);



    % Limit radial distance

    if ~isempty(xMaxNm)

        keep = x <= xMaxNm;

        x   = x(keep);

        mu  = mu(keep);

        sem = sem(keep);

    end



    % Sort

    [x,idx] = sort(x);


    mu  = mu(idx);

    sem = sem(idx);



    Xcell{k}  = x;

    MUcell{k} = mu;

    SEcell{k} = sem;



end



%% =========================================================================
% CREATE COMMON RADIAL GRID
% =========================================================================


xGrid = unique(vertcat(Xcell{:}));

xGrid = sort(xGrid);



MU = nan(numel(xGrid),nGroups);

SE = nan(numel(xGrid),nGroups);



for k = 1:nGroups


    MU(:,k) = interp1( ...
        Xcell{k},...
        MUcell{k},...
        xGrid,...
        'linear',...
        nan);


    SE(:,k) = interp1( ...
        Xcell{k},...
        SEcell{k},...
        xGrid,...
        'linear',...
        nan);


end




%% =========================================================================
% PANEL C
% RADIAL PROFILE OVERLAY
% =========================================================================


figC = figure( ...
    'Color','w',...
    'Units','centimeters',...
    'Position',[3 3 14 10]);

hold on;



hLine = gobjects(nGroups,1);



for k = 1:nGroups


    y = MU(:,k);

    s = SE(:,k);



    ok = ...
        isfinite(xGrid) & ...
        isfinite(y) & ...
        isfinite(s);



    x = xGrid(ok);

    y = y(ok);

    s = s(ok);



    % SEM shaded area

    fill( ...
        [x;flipud(x)],...
        [y-s;flipud(y+s)],...
        fixedCols(k,:),...
        'EdgeColor','none',...
        'FaceAlpha',0.20,...
        'HandleVisibility','off');



    % Mean line

    hLine(k)=plot( ...
        x,...
        y,...
        '-',...
        'Color',fixedCols(k,:),...
        'LineWidth',3,...
        'DisplayName',groupNames{k});



end



xlabel('Distance to FA edge (nm)');


ylabel(sprintf('CH%d normalized intensity',channelToCompare));


title(sprintf('Radial STED profiles CH%d',channelToCompare));


legend(hLine,...
    'Location','northeast',...
    'Box','off',...
    'Interpreter','tex');



xlim([0 xMaxNm]);

ylim([0 1]);



axis square;



set(gca,...
    'FontName','Arial',...
    'FontSize',12,...
    'LineWidth',1,...
    'TickDir','out',...
    'Box','on');



%% SAVE PANEL C

exportgraphics(figC,...
    fullfile(outputDir,...
    sprintf('Appendix1_Figure2C_RadialProfiles_%s.png',timestamp)),...
    'Resolution',600);


print(figC,...
    fullfile(outputDir,...
    sprintf('Appendix1_Figure2C_RadialProfiles_%s.svg',timestamp)),...
    '-dsvg');



fprintf('\nPanel C generated successfully.\n');

%% =========================================================================
% READ EDGE ENRICHMENT DATA
%
% Each sheet:
%
% E:G
% FA_file
% Accum_C2
% Enrich_C2
%
% =========================================================================


fprintf('\nReading edge enrichment data...\n');


EnrichData = cell(nGroups,1);


for k = 1:nGroups


    fprintf('Reading enrichment: %s\n',sheetNames{k});


    Tedge = readtable( ...
        sourceFile,...
        'Sheet',sheetNames{k},...
        'Range','E:G');



    % Column 3 = Enrich_C2

    enrich = Tedge{:,3};



    enrich = enrich(isfinite(enrich));


    EnrichData{k}=enrich;



end



%% =========================================================================
% PANEL D
% EDGE ENRICHMENT BOXPLOT
% =========================================================================


figD = figure( ...
    'Color','w',...
    'Units','centimeters',...
    'Position',[18 3 14 10]);


hold on;



% Convert to matrix

maxN = max(cellfun(@numel,EnrichData));


E = nan(maxN,nGroups);



for k = 1:nGroups

    E(1:numel(EnrichData{k}),k)=EnrichData{k};

end



% Boxplot

boxplot(E,...
    'Labels',groupNames,...
    'Symbol','');



% Style median

set(findobj(gca,'Tag','Median'),...
    'Color','k',...
    'LineWidth',1.5);



% Color boxes

boxes=findobj(gca,'Tag','Box');

boxes=flipud(boxes);


for k=1:numel(boxes)


    patch( ...
        get(boxes(k),'XData'),...
        get(boxes(k),'YData'),...
        fixedCols(k,:),...
        'FaceAlpha',0.30,...
        'EdgeColor',fixedCols(k,:),...
        'LineWidth',1.2,...
        'HandleVisibility','off');

end



% Individual FA points

rng(1);


for k=1:nGroups


    y=EnrichData{k};


    xj=k + ...
        0.08*(rand(size(y))-0.5);


    plot(xj,...
        y,...
        'k.',...
        'MarkerSize',12);


end



% Reference enrichment = 1

yline(1,...
    '--',...
    'Color',[0.45 0.45 0.45],...
    'LineWidth',1);



ylabel(sprintf('Edge enrichment (CH%d)',channelToCompare));


title(sprintf('CH%d edge enrichment',channelToCompare));



ylim([0 max(E(:))*1.15]);



axis square;



set(gca,...
    'FontName','Arial',...
    'FontSize',12,...
    'LineWidth',1,...
    'TickDir','out',...
    'Box','on');



%% SAVE PANEL D


exportgraphics(figD,...
    fullfile(outputDir,...
    sprintf('Appendix1_Figure2D_EdgeEnrichment_%s.png',timestamp)),...
    'Resolution',600);


print(figD,...
    fullfile(outputDir,...
    sprintf('Appendix1_Figure2D_EdgeEnrichment_%s.svg',timestamp)),...
    '-dsvg');



fprintf('\nPanel D generated successfully.\n');



%% =========================================================================
% STATISTICS
% Welch t-tests
%
% Comparisons:
%   Pax vs a5Tot
%   Pax vs actb1
%   Pax vs Ten3
%   Pax vs all other groups combined
%
% =========================================================================


fprintf('\nRunning Welch t-tests...\n');


Summary = table( ...
    string(groupNames(:)),...
    cellfun(@numel,EnrichData(:)),...
    cellfun(@(x) mean(x,'omitnan'),EnrichData(:)),...
    cellfun(@(x) std(x,'omitnan')/sqrt(numel(x)),EnrichData(:)),...
    cellfun(@(x) median(x,'omitnan'),EnrichData(:)),...
    'VariableNames',...
    {'Group','N','Mean','SEM','Median'});



Ttests = table();



% Pax vs each group

for k=2:nGroups


    Ttests=[Ttests; ...
        runWelch( ...
        EnrichData{1},...
        EnrichData{k},...
        groupNames{1},...
        groupNames{k})];


end



% Pax vs all others combined

others = vertcat(EnrichData{2:end});


Ttests=[Ttests; ...
    runWelch( ...
    EnrichData{1},...
    others,...
    groupNames{1},...
    'All others')];



%% Print statistics

disp(' ');
disp('===== Welch t-tests =====');

disp(Ttests);



%% Save statistics Excel


statsFile = fullfile(outputDir,...
    sprintf('Appendix1_Figure2_EdgeEnrichment_statistics_%s.xlsx',timestamp));


writetable(Summary,...
    statsFile,...
    'Sheet','Summary');


writetable(Ttests,...
    statsFile,...
    'Sheet','Welch_ttests');



fprintf('\nStatistics saved:\n%s\n',statsFile);



%% =========================================================================
% LOCAL FUNCTION
% =========================================================================


function out = runWelch(x1,x2,name1,name2)


x1=x1(isfinite(x1));
x2=x2(isfinite(x2));


[h,p,ci,stats]=ttest2(...
    x1,...
    x2,...
    'Vartype','unequal');



out=table(...
    string(name1+" vs "+name2),...
    numel(x1),...
    numel(x2),...
    mean(x1,'omitnan'),...
    mean(x2,'omitnan'),...
    stats.tstat,...
    stats.df,...
    p,...
    ci(1),...
    ci(2),...
    h,...
    'VariableNames',...
    {'Comparison',...
    'N1',...
    'N2',...
    'Mean1',...
    'Mean2',...
    'tstat',...
    'df',...
    'p',...
    'CI_low',...
    'CI_high',...
    'Significant'});


end
