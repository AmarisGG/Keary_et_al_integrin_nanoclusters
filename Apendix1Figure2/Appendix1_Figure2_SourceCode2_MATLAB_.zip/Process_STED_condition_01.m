%% Appendix 1–figure 2
% Process_STED_condition_01.m
%
% Purpose
%   Process radial C2 fluorescence profiles exported from Fiji/ImageJ
%   for one experimental condition.
%
% Input
%   One *_Results.csv file per focal adhesion (FA).
%
% Required columns
%       bin_center_nm
%       C2_meanRaw
%
% Analysis
%   - Uses all available radial bins up to 1000 nm.
%   - Each FA is minimum-subtracted independently.
%   - Each FA is normalized independently to its maximum (0–1).
%   - Profiles are interpolated onto a common radial grid.
%   - No extrapolation is performed outside each FA radial range.
%   - Mean ± SEM is calculated across FAs.
%   - Final radial profiles are reported up to 600 nm.
%   - Edge enrichment per FA:
%
%         mean normalized intensity at 60–180 nm
%         ---------------------------------------
%         mean normalized intensity at 180–600 nm
%
%   For FAs shorter than 600 nm, only available bins within the
%   180–600 nm interval contribute to the denominator.
%
% Output
%   Excel workbook containing:
%       Parameters
%       Profiles_perFA
%       Radial_MeanSEM
%       EdgeMetrics_perFA
%
% No outlier exclusion is performed.
%
% -------------------------------------------------------------------------

clear;
clc;
close all;


%% ========================================================================
% USER SETTINGS
% ========================================================================

% Folder containing *_Results.csv files for ONE condition
dataDir = '\\nas01\SMB02\Amaris\4- Proyectos Theory\Proyecto Sarah\Kearyetal_Paper_elife2025\Appendix 1-figure 2-source data 1\Ten3_\Results FA'; % EDIT_PATH_TO_ONE_CONDITION_FOLDER

% Condition name used in output file
conditionName = 'Paxilin';

% Fiji output filename pattern
filePattern = '*_Results.csv';

% Maximum distance used for normalization
profileMaxNm = 1000;

% Maximum distance reported for final radial profile
displayMaxNm = 600;

% Edge-enrichment regions
edgeRangeNm     = [60 180];
interiorRangeNm = [180 600];

% Final analysis uses C2 only
channelToProcess = 2;


%% ========================================================================
% OUTPUT
% ========================================================================

outputDir = fullfile(dataDir, 'Processed_for_VOR');

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

safeCondition = regexprep(conditionName, '[^\w\-]+', '_');

outXLSX = fullfile( ...
    outputDir, ...
    sprintf('%s_STED_VOR.xlsx', safeCondition));


%% ========================================================================
% FIND INPUT FILES
% ========================================================================

files = dir(fullfile(dataDir, filePattern));
files = files(~[files.isdir]);

if isempty(files)
    error('No files matching "%s" found in:\n%s', ...
        filePattern, dataDir);
end

% Stable alphabetical ordering
[~,ord] = sort(lower(string({files.name})));
files = files(ord);

nFiles = numel(files);

fprintf('\n=========================================\n');
fprintf('Condition: %s\n', conditionName);
fprintf('Number of FA files: %d\n', nFiles);
fprintf('Channel processed: C%d\n', channelToProcess);
fprintf('=========================================\n\n');


%% ========================================================================
% BUILD COMMON RADIAL GRID
% ========================================================================

xGrid = [];

channelColumn = sprintf('C%d_meanRaw', channelToProcess);

for i = 1:nFiles

    fpath = fullfile(files(i).folder, files(i).name);
    T = readtable(fpath);

    if ~ismember('bin_center_nm', T.Properties.VariableNames)
        error('Missing bin_center_nm in file:\n%s', files(i).name);
    end

    if ~ismember(channelColumn, T.Properties.VariableNames)
        error('Missing %s in file:\n%s', ...
            channelColumn, files(i).name);
    end

    x = T.bin_center_nm;

    keep = ...
        isfinite(x) & ...
        x >= 0 & ...
        x <= profileMaxNm;

    x = x(keep);

    xGrid = union(xGrid, x);

end

xGrid = sort(unique(xGrid(:)));

if isempty(xGrid)
    error('No radial distances found up to %g nm.', profileMaxNm);
end


%% ========================================================================
% PREALLOCATE NORMALIZED PROFILE MATRIX
%
% Rows    = radial positions
% Columns = individual FAs
% ========================================================================

A = nan(numel(xGrid), nFiles);


%% ========================================================================
% QC VARIABLES
% ========================================================================

FA_file = string({files.name})';

MaxDistance_nm  = nan(nFiles,1);
N_bins_profile  = nan(nFiles,1);
N_bins_edge     = nan(nFiles,1);
N_bins_interior = nan(nFiles,1);


%% ========================================================================
% NORMALIZE EACH INDIVIDUAL FA
% ========================================================================

for i = 1:nFiles

    fpath = fullfile(files(i).folder, files(i).name);
    T = readtable(fpath);

    xAll = T.bin_center_nm;
    yAll = T.(channelColumn);

    % Keep valid values up to profileMaxNm
    keep = ...
        isfinite(xAll) & ...
        isfinite(yAll) & ...
        xAll >= 0 & ...
        xAll <= profileMaxNm;

    x = xAll(keep);
    y = yAll(keep);

    if numel(x) < 2
        warning('%s contains fewer than two valid C2 radial bins.', ...
            files(i).name);
        continue;
    end

    % Sort radial distances
    [x,idx] = sort(x(:));
    y = y(idx);

    % Remove duplicate radial positions if present
    [x,ia] = unique(x, 'stable');
    y = y(ia);

    % QC
    MaxDistance_nm(i) = max(x);
    N_bins_profile(i) = numel(x);

    N_bins_edge(i) = sum( ...
        x >= edgeRangeNm(1) & ...
        x < edgeRangeNm(2));

    N_bins_interior(i) = sum( ...
        x >= interiorRangeNm(1) & ...
        x <= interiorRangeNm(2));

    % Minimum subtraction
    yMin = min(y, [], 'omitnan');
    yMS = y - yMin;

    % Normalize to 0–1
    yMax = max(yMS, [], 'omitnan');

    if ~isfinite(yMax) || yMax <= 0
        warning('%s could not be normalized because intensity range is zero.', ...
            files(i).name);
        continue;
    end

    yNorm = yMS ./ yMax;

    % Interpolate to common radial grid
    % Values outside the available FA range remain NaN
    A(:,i) = interp1( ...
        x, ...
        yNorm, ...
        xGrid, ...
        'linear', ...
        nan);

end


%% ========================================================================
% MEAN + SD + SEM ACROSS FAs
% ========================================================================

meanProfile = mean(A, 2, 'omitnan');

sdProfile = std(A, 0, 2, 'omitnan');

nProfile = sum(isfinite(A), 2);

semProfile = sdProfile ./ sqrt(max(nProfile,1));


%% ========================================================================
% EDGE ENRICHMENT PER FA
% ========================================================================

edgeMask = ...
    xGrid >= edgeRangeNm(1) & ...
    xGrid < edgeRangeNm(2);

interiorMask = ...
    xGrid >= interiorRangeNm(1) & ...
    xGrid <= interiorRangeNm(2);

if ~any(edgeMask)
    error('No bins found in edge range [%g,%g) nm.', ...
        edgeRangeNm(1), edgeRangeNm(2));
end

if ~any(interiorMask)
    error('No bins found in interior range [%g,%g] nm.', ...
        interiorRangeNm(1), interiorRangeNm(2));
end

edgeMean     = nan(nFiles,1);
interiorMean = nan(nFiles,1);
enrich       = nan(nFiles,1);

for i = 1:nFiles

    y = A(:,i);

    edgeValues = y(edgeMask);
    interiorValues = y(interiorMask);

    edgeMean(i) = mean(edgeValues, 'omitnan');

    interiorMean(i) = mean(interiorValues, 'omitnan');

    if ...
            isfinite(edgeMean(i)) && ...
            isfinite(interiorMean(i)) && ...
            interiorMean(i) > 0

        enrich(i) = edgeMean(i) / interiorMean(i);

    end

end


%% ========================================================================
% EDGE METRICS TABLE
% ========================================================================

EdgeMetrics = table( ...
    FA_file, ...
    MaxDistance_nm, ...
    N_bins_profile, ...
    N_bins_edge, ...
    N_bins_interior, ...
    edgeMean, ...
    interiorMean, ...
    enrich, ...
    'VariableNames', { ...
    'FA_file', ...
    'MaxDistance_nm', ...
    'N_bins_profile', ...
    'N_bins_edge', ...
    'N_bins_interior', ...
    'EdgeMean_C2', ...
    'InteriorMean_C2', ...
    'Enrich_C2'});


%% ========================================================================
% INDIVIDUAL NORMALIZED PROFILES
% ========================================================================

Condition = strings(0,1);
FA = strings(0,1);
Channel = zeros(0,1);
Distance_nm = zeros(0,1);
Normalized_intensity = zeros(0,1);

for i = 1:nFiles

    nRows = numel(xGrid);

    Condition = [ ...
        Condition; ...
        repmat(string(conditionName), nRows, 1)]; %#ok<AGROW>

    FA = [ ...
        FA; ...
        repmat(string(files(i).name), nRows, 1)]; %#ok<AGROW>

    Channel = [ ...
        Channel; ...
        repmat(channelToProcess, nRows, 1)]; %#ok<AGROW>

    Distance_nm = [ ...
        Distance_nm; ...
        xGrid]; %#ok<AGROW>

    Normalized_intensity = [ ...
        Normalized_intensity; ...
        A(:,i)]; %#ok<AGROW>

end

IndividualProfiles = table( ...
    Condition, ...
    FA, ...
    Channel, ...
    Distance_nm, ...
    Normalized_intensity);


%% ========================================================================
% RADIAL SUMMARY FOR FINAL FIGURE
% ========================================================================

displayMask = ...
    xGrid >= 0 & ...
    xGrid <= displayMaxNm;

xDisplay = xGrid(displayMask);

RadialSummary = table( ...
    xDisplay, ...
    meanProfile(displayMask), ...
    semProfile(displayMask), ...
    nProfile(displayMask), ...
    'VariableNames', { ...
    'bin_center_nm', ...
    'C2_meanNorm', ...
    'C2_SEM', ...
    'C2_N_FA'});


%% ========================================================================
% PARAMETERS TABLE
% ========================================================================

Parameter = [
    "Condition"
    "Channel processed"
    "Number of FA files"
    "Maximum distance used for normalization (nm)"
    "Maximum displayed distance (nm)"
    "Edge window (nm)"
    "Interior window (nm)"
    "Normalization"
    "Interpolation"
    "Outlier exclusion"
    ];

Value = [
    string(conditionName)
    "C" + string(channelToProcess)
    string(nFiles)
    string(profileMaxNm)
    string(displayMaxNm)
    "[" + string(edgeRangeNm(1)) + "," + string(edgeRangeNm(2)) + ")"
    "[" + string(interiorRangeNm(1)) + "," + string(interiorRangeNm(2)) + "]"
    "Minimum subtraction followed by individual 0-1 normalization"
    "Linear interpolation; no extrapolation outside each FA radial range"
    "None"
    ];

Parameters = table(Parameter, Value);


%% ========================================================================
% SAVE EXCEL WORKBOOK
% ========================================================================

if exist(outXLSX, 'file')
    delete(outXLSX);
end

writetable( ...
    Parameters, ...
    outXLSX, ...
    'Sheet', 'Parameters');

writetable( ...
    IndividualProfiles, ...
    outXLSX, ...
    'Sheet', 'Profiles_perFA');

writetable( ...
    RadialSummary, ...
    outXLSX, ...
    'Sheet', 'Radial_MeanSEM');

writetable( ...
    EdgeMetrics, ...
    outXLSX, ...
    'Sheet', 'EdgeMetrics_perFA');


%% ========================================================================
% CONSOLE SUMMARY
% ========================================================================

fprintf('\n=========================================\n');
fprintf('Processing completed successfully.\n');
fprintf('Condition: %s\n', conditionName);
fprintf('Total FA files: %d\n', nFiles);

fprintf( ...
    'Valid edge-enrichment values: %d / %d\n', ...
    sum(isfinite(enrich)), ...
    nFiles);

fprintf('\nN contributing FAs by radial distance:\n');

nDisplay = nProfile(displayMask);

for j = 1:numel(xDisplay)

    fprintf( ...
        '%4g nm : N = %d\n', ...
        xDisplay(j), ...
        nDisplay(j));

end

fprintf('\nSaved:\n%s\n', outXLSX);
fprintf('=========================================\n');